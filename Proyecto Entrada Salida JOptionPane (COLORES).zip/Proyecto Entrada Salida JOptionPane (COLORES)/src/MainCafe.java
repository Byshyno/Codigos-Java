import calculos.Cafe;
import calculos.Numeros;
import calculos.Totales;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.Locale;

public class MainCafe {

    // ---------------------------------------------------------------
    // Estilo visual: colores tomados del logo de Cafetalera
    // ---------------------------------------------------------------
    private static final String TITULO = "Cafetalera S.A";
    private static final String FUENTE = "SansSerif";   // cambia aquí el tipo de letra

    private static final Color CREMA = new Color(250, 243, 228);        // fondo
    private static final Color CAFE_OSCURO = new Color(74, 37, 17);     // texto y bordes
    private static final Color CARAMELO = new Color(214, 160, 92);      // menú y marco
    private static final Color VERDE = new Color(63, 125, 58);          // aceptar
    private static final Color ROJO = new Color(190, 50, 45);           // errores

    private static final String HEX_VERDE = "#2E6B2E";
    private static final String HEX_ROJO = "#B3261E";

    // Configura colores, fuentes y bordes de todos los JOptionPane
    private static void configurarEstilo() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            // Si falla, se usa el aspecto por defecto del sistema
        }

        Font fuenteTexto = new Font(FUENTE, Font.PLAIN, 14);
        Font fuenteBoton = new Font(FUENTE, Font.BOLD, 13);

        UIManager.put("OptionPane.background", CREMA);
        UIManager.put("Panel.background", CREMA);
        UIManager.put("OptionPane.messageForeground", CAFE_OSCURO);
        UIManager.put("OptionPane.messageFont", fuenteTexto);
        UIManager.put("OptionPane.buttonFont", fuenteBoton);
        UIManager.put("OptionPane.border", BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CARAMELO, 4),
                BorderFactory.createEmptyBorder(14, 16, 12, 16)));

        UIManager.put("Label.font", fuenteTexto);
        UIManager.put("Label.foreground", CAFE_OSCURO);

        UIManager.put("TextField.font", fuenteTexto);
        UIManager.put("TextField.foreground", CAFE_OSCURO);
        UIManager.put("TextField.background", Color.WHITE);
        UIManager.put("TextField.border", BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CAFE_OSCURO, 1),
                BorderFactory.createEmptyBorder(4, 6, 4, 6)));

        UIManager.put("Button.border", BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CAFE_OSCURO, 1),
                BorderFactory.createEmptyBorder(6, 18, 6, 18)));

        // Textos de los botones estándar, como en el diseño del enunciado
        UIManager.put("OptionPane.okButtonText", "OK");
        UIManager.put("OptionPane.cancelButtonText", "CANCEL");
    }

    // Cambia los colores de los botones del siguiente diálogo
    private static void estiloBotones(Color fondo, Color texto) {
        UIManager.put("Button.background", fondo);
        UIManager.put("Button.foreground", texto);
        UIManager.put("Button.select", fondo.darker());
        UIManager.put("Button.focus", texto);
    }

    // Arma el mensaje con formato (HTML) y un ancho fijo para que se vea ordenado
    private static JLabel mensaje(String html) {
        return mensaje(html, 290);
    }

    private static JLabel mensaje(String html, int ancho) {
        return new JLabel("<html><body style='width:" + ancho + "px'>" + html + "</body></html>");
    }

    // Da formato de dinero con dos decimales (B/. 2.00)
    private static String dinero(double valor) {
        return String.format(Locale.US, "B/. %.2f", valor);
    }

    // Carga una imagen y la ajusta al ancho indicado (conserva la proporción);
    // si el archivo no existe, devuelve null y el programa sigue sin ella
    private static ImageIcon cargarIcono(String ruta, int ancho) {
        if (!new File(ruta).exists()) {
            return null;
        }
        Image imagen = new ImageIcon(ruta).getImage().getScaledInstance(ancho, -1, Image.SCALE_SMOOTH);
        return new ImageIcon(imagen);
    }

    // ---------------------------------------------------------------
    // Programa principal
    // ---------------------------------------------------------------
    public static void main(String[] args) {
        configurarEstilo();

        Cafe obj = new Cafe();
        Numeros obj1 = new Numeros();

        ImageIcon ima = cargarIcono("imagenes/LOGO.png", 180);
        ImageIcon ima1 = cargarIcono("imagenes/CAFE1-2.png", 230);
        ImageIcon ima2 = cargarIcono("imagenes/BOLSAS.png", 220);
        ImageIcon ima3 = cargarIcono("imagenes/Error.jpg", 70);
        ImageIcon ima4 = cargarIcono("imagenes/Factura.png", 160);
        ImageIcon ima5 = cargarIcono("imagenes/NuevoPed.png", 320);
        ImageIcon ima6 = cargarIcono("imagenes/Ganancias.png", 260);

        // acumuladores
        Totales acuG = new Totales();
        Totales acu1 = new Totales();
        Totales acu2 = new Totales();

        //contadores
        Totales cont1 = new Totales();
        Totales cont2 = new Totales();
        Totales cont3 = new Totales();


        int tipoC = 0, cantB = 0, resp = 0;
        double totalP = 0.00, totalF = 0.00;
        boolean leido = true, cancelado = false;
        String tipoCaf = "", caja = "", entrada;

        // Bienvenida (una sola vez, antes del primer pedido)
        estiloBotones(VERDE, Color.WHITE);
        JOptionPane.showMessageDialog(null,
                mensaje("<b style='font-size:16px; color:" + HEX_VERDE + "'>¡Bienvenido a Cafetalera S.A.!</b>"
                        + "<br><br>Café de altura cultivado en Boquete."),
                TITULO, JOptionPane.INFORMATION_MESSAGE, ima);

        while (resp == 0) {

            // ---- Menú principal ----
            Object[] opciones = {"1. Arábica", "2. Robusta"}; // Arreglo que permite cambiar el nombre a los botones!
            estiloBotones(CARAMELO, CAFE_OSCURO);
            tipoC = JOptionPane.showOptionDialog(null,
                    mensaje("<b style='font-size:15px'>¿Qué tipo de café desea adquirir?</b><br><br>"
                            + "1. Arábica (" + dinero(obj.getCafe1()) + " por bolsa)<br>"
                            + "2. Robusta (" + dinero(obj.getCafe2()) + " por bolsa)"),
                    TITULO, JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, ima1, opciones, opciones[0]);

            if (tipoC == -1) {   // cerró el menú con la X: se pasa al reporte final
                break;
            }

            // ---- Lectura y validación de la cantidad de bolsas ----
            cancelado = false;
            do {
                leido = true;
                try {
                    estiloBotones(VERDE, Color.WHITE);
                    entrada = (String) JOptionPane.showInputDialog(null,
                            mensaje("¿Cuántas bolsas de café desea?<br>(2 kg cada bolsa)"),
                            TITULO, JOptionPane.QUESTION_MESSAGE, ima2, null, null);

                    if (entrada == null) {   // presionó CANCEL: vuelve al menú
                        cancelado = true;
                    } else {
                        cantB = Integer.parseInt(entrada.trim());
                        if (cantB <= 0) {
                            estiloBotones(ROJO, Color.WHITE);
                            JOptionPane.showMessageDialog(null,
                                    mensaje("<b style='color:" + HEX_ROJO + "'>Error:</b> el valor no puede ser 0 o negativo."
                                            + "<br>Ingrese nuevamente la cantidad de bolsas."),
                                    TITULO, JOptionPane.ERROR_MESSAGE, ima3);
                            leido = false;
                        }
                    }
                } catch (NumberFormatException e) {
                    estiloBotones(ROJO, Color.WHITE);
                    JOptionPane.showMessageDialog(null,
                            mensaje("<b style='color:" + HEX_ROJO + "'>Error:</b> dato inválido."
                                    + "<br>Ingrese nuevamente la cantidad de bolsas."),
                            TITULO, JOptionPane.ERROR_MESSAGE, ima3);
                    leido = false;
                }
            } while (!leido);

            if (cancelado) {
                continue;
            }

            // ---- Cálculos del pedido ----
            obj.setTipoC(tipoC);
            obj.setCantB(cantB);
            obj1.setTipoC(tipoC);
            obj1.setCantB(cantB);

            totalP = obj.calcularPe();
            tipoCaf = obj.calcularTiC();

            obj1.acumular(totalP, acu1, acu2);
            acuG.acumular(totalP);

            obj1.contar(cont1, cont2, cont3);
            totalF = obj.calcularPf(totalP, cont1, cont2, cont3);
            caja = obj.calcularCa(cont1, cont2, cont3);

            // ---- Resumen del pedido ----
            estiloBotones(VERDE, Color.WHITE);
            JOptionPane.showMessageDialog(null,
                    mensaje("<b style='font-size:15px; color:" + HEX_VERDE + "'>RESUMEN DEL PEDIDO</b><br><br>"
                            + "Café: <b>" + tipoCaf + "</b><br>"
                            + "Cantidad de bolsas pedidas: <b>" + cantB + "</b><br>"
                            + "Costo del pedido: <b>" + dinero(totalP) + "</b><br><br>"
                            + "<b>Cajas usadas</b><br>" + caja.replace("\n\n", "<br>").replace("\n", "<br>") + "<br>"
                            + "<b style='font-size:15px; color:" + HEX_VERDE + "'>Costo total a pagar: "
                            + dinero(totalF) + "</b>"),
                    TITULO, JOptionPane.INFORMATION_MESSAGE, ima4);

            // ---- ¿Otro pedido? ----
            Object[] botones = {"Sí, otro pedido", "Salir"};
            estiloBotones(CARAMELO, CAFE_OSCURO);
            resp = JOptionPane.showOptionDialog(null,
                    mensaje("<b style='font-size:15px'>¿Nuevo pedido de café?</b>", 150),
                    TITULO, JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, ima5, botones, botones[0]);

        }

        // ---- Reporte final de ventas ----
        estiloBotones(VERDE, Color.WHITE);
        JOptionPane.showMessageDialog(null,
                mensaje("<b style='font-size:15px; color:" + HEX_VERDE + "'>REPORTE FINAL DE VENTAS</b><br><br>"
                        + "Total de ingresos obtenidos por la venta de café Arábica:<br>"
                        + "<b>" + dinero(acu1.getAcu()) + "</b><br><br>"
                        + "Total de ingresos obtenidos por la venta de café Robusta:<br>"
                        + "<b>" + dinero(acu2.getAcu()) + "</b><br><br>"
                        + "<b style='font-size:15px; color:" + HEX_VERDE + "'>Total general de ventas realizadas:<br>"
                        + dinero(acuG.getAcu()) + "</b>"),
                TITULO, JOptionPane.INFORMATION_MESSAGE, ima6);

    }
}

