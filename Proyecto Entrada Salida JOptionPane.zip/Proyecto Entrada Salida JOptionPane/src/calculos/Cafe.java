package calculos;

public class Cafe {
    private int tipoC,cantB;
    private double cafe1,cafe2,cajaG,cajaM,cajaP;

    public Cafe (){
        cafe1 = 5.50; cafe2 = 10.00; cajaG = 2.00; cajaM = 1.00; cajaP = 0.50;
    }

    public int getTipoC() {
        return tipoC;
    }

    public void setTipoC(int tipoC) {
        this.tipoC = tipoC;
    }

    public int getCantB() {
        return cantB;
    }

    public void setCantB(int cantB) {
        this.cantB = cantB;
    }

    public double getCafe1() {
        return cafe1;
    }

    public void setCafe1(double cafe1) {
        this.cafe1 = cafe1;
    }

    public double getCafe2() {
        return cafe2;
    }

    public void setCafe2(double cafe2) {
        this.cafe2 = cafe2;
    }

    public double getCajaM() {
        return cajaM;
    }

    public void setCajaM(double cajaM) {
        this.cajaM = cajaM;
    }

    public double getCajaG() {
        return cajaG;
    }

    public void setCajaG(double cajaG) {
        this.cajaG = cajaG;
    }

    public double getCajaP() {
        return cajaP;
    }

    public void setCajaP(double cajaP) {
        this.cajaP = cajaP;
    }

    public double calcularPe (){
        double tot=0.00;
        if (tipoC==0){
            tot= cafe1 * cantB;
        } else {
            tot = cafe2 * cantB;
        }
        return tot;
    }

    public String calcularTiC () { // Metodo que decide cual tipo de cafe estoy usando
        String tipo ="";
        if (tipoC ==0){
            tipo = "Arábica";
        } else if (tipoC == 1) {
            tipo = "Robusta";
        }
        return tipo;
    }

    public double calcularPf (double totP,Totales acu1,Totales acu2, Totales acu3) { // Metodo que calcula el precio final (incluido el precio de las cajas)
        return totP + acu1.getCount() * cajaG
                + acu2.getCount() * cajaM
                + acu3.getCount() * cajaP;
    }

    public String calcularCa(Totales cont1, Totales cont2, Totales cont3) { // Metodo que me concaneta las cajas a usar mas su cantidad
        String detalle = "";
        if (cont1.getCount() > 0) {
            detalle += " Grande: " + cont1.getCount() + "\n\n";
        }
        if (cont2.getCount() > 0) {
            detalle += " Mediana: " + cont2.getCount() + "\n\n";
        }
        if (cont3.getCount() > 0) {
            detalle += " Pequeña: " + cont3.getCount() + "\n\n";
        }
        return detalle;
    }

    
}
