package calculos;

public class Totales {
    private double acu;
    private int count;

    public double getAcu() {
        return acu;
    }
    public int getCount (){
        return count;
    }

    // Acumula el dinero de cada tipo de cafe y general
    public void acumular(double valor) {
        acu = acu + valor; // metodo que acumula todas las ventas de los cafes y en general
    }
    // cuenta cada tipo de bolsa
    public void contar (){
        count = count+1; // metodo que cuenta las bolsas necesarias
    }

    public void reiniciar () {
        count = 0; // metodo que reinician contenido para que no se acumule
    }
}
