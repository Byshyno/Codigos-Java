package calculos;

public class Numeros {
    private int tipoC, cantB;

    public void setTipoC(int tipoC) {
        this.tipoC = tipoC;
    }
    public  void setCantB (int cantB){
        this.cantB = cantB;
    }



    public void acumular(double valor, Totales acu1, Totales acu2) {
        if (tipoC==0){
            acu1.acumular(valor);
        } else {
            acu2.acumular(valor);
        }

    } 
    public  void contar (Totales acu1,Totales acu2, Totales acu3){
        acu1.reiniciar();
        acu2.reiniciar();
        acu3.reiniciar();
        while (cantB>0) {
            if (cantB > 10) {
                acu1.contar();
                cantB = cantB - 20;
            } else if (cantB >5) {
                acu2.contar();
                cantB = cantB - 10;
            } else {
                acu3.contar();
                cantB = cantB - 5;
            }
        }
    }
    
    

}

