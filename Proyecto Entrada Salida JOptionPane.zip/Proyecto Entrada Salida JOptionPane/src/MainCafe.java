import calculos.Cafe;
import calculos.Numeros;
import calculos.Totales;

import javax.swing.*;
import java.awt.*;

public class MainCafe {

    public static void main(String[] args) {
        Cafe obj = new Cafe();
        Numeros obj1 =  new Numeros();

        ImageIcon ima = new ImageIcon("imagenes/LOGO.png");
        ImageIcon ima1 = new ImageIcon("imagenes/CAFE1-2.png");
        ImageIcon ima2 = new ImageIcon("imagenes/BOLSAS.png");
        ImageIcon ima3 = new ImageIcon("imagenes/Error.jpg");
        ImageIcon ima4 = new ImageIcon("imagenes/Factura.png");
        ImageIcon ima5 = new ImageIcon("imagenes/NuevoPed.png");
        ImageIcon ima6 = new ImageIcon("imagenes/Ganancias.png");



        // acumuladores
        Totales acuG = new Totales();
        Totales acu1 = new Totales();
        Totales acu2 = new Totales();

        //contadores
        Totales cont1 = new Totales();
        Totales cont2 = new Totales();
        Totales cont3 = new Totales();


        int tipoC=0, cantB = 0,resp=0;
        double totalP=0.00,totalF=0.00;
        boolean leido = true;
        String tipoCaf="", caja="";

        while (resp==0){

            JOptionPane.showMessageDialog(null, "Bienvenido a Cafetalera S.A!","Cafetalera S.A",JOptionPane.QUESTION_MESSAGE, ima);

                Object[] opciones = {"1. Arábica", "2. Robusta"}; // Arreglo que permite cambiar el nombre a los botones!
                tipoC = JOptionPane.showOptionDialog(null, "¿Que tipo de cafe desea adquirir? \n 1. Arábica (B/. 5.50) 2. Robusta (B/. 10.00)",
                        "Cafetalera S.A",JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, ima1, opciones, opciones[0]);

                do { try { leido = true;
                    cantB = Integer.parseInt((String) JOptionPane.showInputDialog(null,"¿Cuántas bolsas de café desea? \n (2 kg cada bolsa)","Cafetalera S.A",
                            JOptionPane.QUESTION_MESSAGE, ima2, null, null));
                    if (cantB <=0){
                        JOptionPane.showMessageDialog(null,"Error, el valor no puede ser 0 o negativo, ingrese nuevamente la cantidad de bolsas!",
                                "Cafetalera S.A",JOptionPane.QUESTION_MESSAGE,ima3);
                        leido = false;
                    }
                } catch (NumberFormatException e){
                    JOptionPane.showMessageDialog(null,"Error, dato invalido, ingrese nuevamente la cantidad de bolsas!",
                            "Cafetalera S.A",JOptionPane.QUESTION_MESSAGE,ima3);
                    leido = false;
                }
                } while (!leido);

                obj.setTipoC(tipoC);
                obj.setCantB(cantB);
                obj1.setTipoC(tipoC);
                obj1.setCantB(cantB);

                totalP = obj.calcularPe();
                tipoCaf = obj.calcularTiC();

                obj1.acumular(totalP,acu1,acu2);
                acuG.acumular(totalP);

                obj1.contar(cont1,cont2,cont3);
                totalF = obj.calcularPf(totalP,cont1,cont2,cont3);
                caja = obj.calcularCa(cont1,cont2,cont3);


            JOptionPane.showMessageDialog(null, "Cafe: " + tipoCaf + "\n \n Cantidad de bolsas pedidas: " + cantB + "\n \n Costo del pedido: $" + totalP
                            + "\n \n Cajas usadas\n \n" + caja + " Costo total a pagar: $" + totalF, "Cafetalera S.A", JOptionPane.QUESTION_MESSAGE,ima4);


            Object[] botones = {"Sí, otro pedido", "Salir"};
            resp = JOptionPane.showOptionDialog(null, "¿Nuevo pedido de café?", "Cafetalera S.A",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, ima5, botones, botones[0]);

        }

        JOptionPane.showMessageDialog(null,"\n\n Total de ingresos obtenidos por la venta de café Arábica: $"+acu1.getAcu()+"\n\n Total de ingresos obtenidos por la venta de café Robusta: $"
                +acu2.getAcu()+"\n\n Total general de ventas realizada: $"+acuG.getAcu(),"Cafetalera S.A",JOptionPane.QUESTION_MESSAGE,ima6);


    }
}
